Share Icon
v 1.01, 2006-12-12

This is a "Share" Icon - to be used to represent generic "sharing" of an item. Please see detailed information here:

http://shareicons.com

This image is licensed under the following licenses:

GPL - http://opensource.org/licenses/gpl-license.php
LGPL - http://opensource.org/licenses/lgpl-license.php
BSD - http://opensource.org/licenses/bsd-license.php
Creative Commons Attribution 2.5 License - http://creativecommons.org/licenses/by/2.5/

The 16x16, 12x12 and 10x10 pixel images were created by Luke Wojewoda - http://eldub.com

Thanks to Jonas Rogne for the additional .png and .ico files. www.rognemedia.no

Enjoy.

--Alex King
http://alexking.org